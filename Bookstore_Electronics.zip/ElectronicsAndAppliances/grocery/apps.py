from django.apps import AppConfig


class GroceryConfig(AppConfig):
    name = 'grocery'
